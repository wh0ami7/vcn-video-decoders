# Changelog

## 1.2.2

- The service needs SIP's Debugging Restrictions off (bit 0x4 of csr-active-config). With them on, macOS refuses
  the service access to Apple's encoder process even as root, so nothing was patched and the log only said
  "task_for_pid failed ((os/kern) failure)". This was never documented: the test machine had SIP fully relaxed. In
  15.8.3's AMFI (checked in IDA), root only gets the task port of such a process when csr_check(CSR_ALLOW_TASK_FOR_PID)
  allows it.
- `vcnencodefix status` (and so doctor.sh and install.sh) shows an "access" line: allowed, or REFUSED with what to
  change. install.sh warns but still installs. The service logs a warning at start and names SIP in each refused
  access.
- README: the requirement, how to set it in OpenCore, and a troubleshooting entry.
- The service ran as a launchd Background job, i.e. at priority 4. When the CPU was busy it could notice a new encoder
  service late: once 1.6 s after launch while OBS started a 5120x2160 recording, and up to 561 ms with every core
  loaded (normally 25-100 ms). OBS sends its first frame about 260 ms after the launch, and an unpatched encode wider
  than 4096 stalls the GPU. The job is now ProcessType Interactive. Its CPU use stays about 0.5% of one core.
- The 10 ms check looked at each new pid once. launchd starts the service in a fork of itself (about 1 ms), then
  xpcproxy (about 11 ms with every core loaded), then the service, so a pid caught in one of the first two stages
  waited for the next full scan (up to 250 ms; measured up to 235 ms with every core loaded). Such a pid is now
  checked again on every tick until it becomes the service.
- The kext is unchanged from 1.2.1 except for the version number.

## 1.2.1

- install.sh --efi wrote the kext's OpenCore entry with MinKernel 25.0.0 (Tahoe), so on macOS 14 and 15 OpenCore
  skipped VCNEncodeFloor.kext and doctor.sh said "not loaded". This came from 1.0.0, when only Tahoe was supported,
  and was missed when 1.1.0 added Sonoma and Sequoia. New entries now use MinKernel 23.0.0, the same range as the
  kext's Lilu configuration.
- efi-add updates an entry written by 1.0.0 to 1.2.0 in place: it changes only that MinKernel line, verifies the
  result and keeps a backup. Running `sudo ./install.sh --efi /Volumes/EFI` again is enough. efi-check reports such
  an entry as "old entry".
- doctor.sh: on macOS 14/15, "not loaded" now points to that fix.
- The kext and the service are unchanged from 1.2.0 except for the version number.

## 1.2.0

- VCNEncodeFloor.kext also hooks AMDRadeonX6800HWLibs, the second Navi 21 power library in macOS. macOS loads
  AMDRadeonX6000HWLibs for the RX 6800 / 6800 XT / 6900 XT, but setups with NootRX load AMDRadeonX6800HWLibs instead,
  and there the clock floor stayed at "waiting for AMDRadeonX6000HWLibs". PEM_CWDDEPM_PMRequest is the same code in
  both libraries (Hex-Rays: only the source line numbers of its log calls differ), in 14.8.9, 15.8.2, 15.8.3 and
  26.7.3; 14.8.9 ships X6800HWLibs stripped too, so there it is routed at its offset after a 32-byte compare.
- Each library keeps its own trampoline, so a Mac with two Navi 21 cards that load both is handled.
- Not run on a GPU with X6800HWLibs: the floor value was measured on an RX 6800 XT, and other cards' clock levels come
  from their own VBIOS.

## 1.1.0

- Supports macOS 14.8.9 (23J631), 15.8.2 (24H232), 15.8.3 (24H241) and 26.7.3 (25G342). Each patch keeps a table of
  validated builds (LC_UUID) with the exact bytes it expects; any other build is still left alone.
  - Apple's HEVC encoder plug-in is the same file in 15.8.2 and 15.8.3; the call site moved (0x13780 on 15.8.x,
    0x142CA on 14.8.9) and on 14.8.9 two kept register moves differ. The Metal kernel uses only
    thread_position_in_grid in every build.
  - AMDRadeonVADriver2 is the same in 15.8.2 and 15.8.3; on 14.8.9 only the jump distance after the preset load
    differs. VAUveEncoder::EncodePicture reads the preset the same way in all of them.
  - AMDRadeonX6000HWLibs: 15.8.x is identical to 26.7.3 in PEM_CWDDEPM_PMRequest, PP_Cwdde and PEM_ClockChange;
    14.8.9 ships the kext without symbols, so the kext routes the function at its offset after comparing its first
    32 bytes. The payload layout (client type +16, minMclk +36, VclkFloor +60) is the same in every build.
- VCNEncodeFloor.kext loads on Sonoma to Tahoe (it was Tahoe only).
- tests: the wide-patch CPU test runs once per validated build of the plug-in.
- Only 26.7.3 has been run on a GPU. The other builds were checked in IDA and with the CPU test only.

## 1.0.1

- vcnencodefix: new encoder services are found within about 10 ms of launch instead of up to 250 ms. In OBS at
  5120x2160 the first frame arrived before the service was patched and stalled the GPU once at the start.
- vcnencodefix: log lines have milliseconds; the wide patch is applied before the preset patch.
- doctor.sh: fixed the kext state and pid display. test.sh: fixed a message error in the wide test.
## 1.0.0

First release, for macOS 26.7.3 (25G342) on Navi 21.

- VCNEncodeFloor.kext: VCN clock floor for hardware encode sessions (Lilu plugin). Checks the AMDRadeonX6000HWLibs
  build before hooking it and publishes its state on IOResources.
- vcnencodefix service: VCN speed preset for every encode; HEVC widths above 4096 no longer stall the GPU.
- install.sh / uninstall.sh, including the OpenCore config.plist entry (backup and verification).
- doctor.sh and test.sh.
